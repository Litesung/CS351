
main()
{
  // Load needed vars
  
  /* Read section */
  // Loop 
    // Check value of number ( >9999 or 9999)
    // Store number into list
    // Repeat unless number is 9999
  // End Loop


  /* Instruction set */ 
  // Loop
    // Get an instruction
    // Verify for validity
    // Store in instruction set
  // End Loop
 
  // Interpreter loop
    // Switch
      // 1xxx, add to accumulator
      // 2xxx, store into slot XXX
      // 3xxx, add contents of slot XXX to accumulator
      // 4xxx, sub contents of slot XXX from accumulator
      // 5xxx, check if negative, then jump to XXX 
      // 6xxx, All done
  // End Loop

}


