#!/bin/bash
g++ interp.c
./a.out < hw1.in > hw1.out
cat hw1.out
